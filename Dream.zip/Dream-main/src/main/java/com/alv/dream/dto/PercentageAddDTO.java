package com.alv.dream.dto;



public class PercentageAddDTO {
	 public int one;
	 public int two;
	 public int three;
	 public int four;
	 public int five;
	 public int six;
	 public int seven;
	 public int eight;
	 public int nine;
	 public int ten;
	 public int eleven;
	 public int twelve;
	 public int thirteen;
	 public int fourteen;
	 public int fifteen;
	 public int sixteen;
	 public int seventeen;
	 public int eighteen;
	 public int nineteen;
	 public int twenty;
	 public int twentyone;
	 @Override
	public String toString() {
		return "PercentageAddDTO [one=" + one + ", two=" + two + ", three=" + three + ", four=" + four + ", five="
				+ five + ", six=" + six + ", seven=" + seven + ", eight=" + eight + ", nine=" + nine + ", ten=" + ten
				+ ", eleven=" + eleven + ", twelve=" + twelve + ", thirteen=" + thirteen + ", fourteen=" + fourteen
				+ ", fifteen=" + fifteen + ", sixteen=" + sixteen + ", seventeen=" + seventeen + ", eighteen="
				+ eighteen + ", nineteen=" + nineteen + ", twenty=" + twenty + ", twentyone=" + twentyone
				+ ", twentytwo=" + twentytwo + ", c=" + c + ", vc=" + vc + "]";
	}
	public int twentytwo;
	 public int c;
	 public int vc;
	public int getOne() {
		return one;
	}
	public void setOne(int one) {
		this.one = one;
	}
	public int getTwo() {
		return two;
	}
	public void setTwo(int two) {
		this.two = two;
	}
	public int getThree() {
		return three;
	}
	public void setThree(int three) {
		this.three = three;
	}
	public int getFour() {
		return four;
	}
	public void setFour(int four) {
		this.four = four;
	}
	public int getFive() {
		return five;
	}
	public void setFive(int five) {
		this.five = five;
	}
	public int getSix() {
		return six;
	}
	public void setSix(int six) {
		this.six = six;
	}
	public int getSeven() {
		return seven;
	}
	public void setSeven(int seven) {
		this.seven = seven;
	}
	public int getEight() {
		return eight;
	}
	public void setEight(int eight) {
		this.eight = eight;
	}
	public int getNine() {
		return nine;
	}
	public void setNine(int nine) {
		this.nine = nine;
	}
	public int getTen() {
		return ten;
	}
	public void setTen(int ten) {
		this.ten = ten;
	}
	public int getEleven() {
		return eleven;
	}
	public void setEleven(int eleven) {
		this.eleven = eleven;
	}
	public int getTwelve() {
		return twelve;
	}
	public void setTwelve(int twelve) {
		this.twelve = twelve;
	}
	public int getThirteen() {
		return thirteen;
	}
	public void setThirteen(int thirteen) {
		this.thirteen = thirteen;
	}
	public int getFourteen() {
		return fourteen;
	}
	public void setFourteen(int fourteen) {
		this.fourteen = fourteen;
	}
	public int getFifteen() {
		return fifteen;
	}
	public void setFifteen(int fifteen) {
		this.fifteen = fifteen;
	}
	public int getSixteen() {
		return sixteen;
	}
	public void setSixteen(int sixteen) {
		this.sixteen = sixteen;
	}
	public int getSeventeen() {
		return seventeen;
	}
	public void setSeventeen(int seventeen) {
		this.seventeen = seventeen;
	}
	public int getEighteen() {
		return eighteen;
	}
	public void setEighteen(int eighteen) {
		this.eighteen = eighteen;
	}
	public int getNineteen() {
		return nineteen;
	}
	public void setNineteen(int nineteen) {
		this.nineteen = nineteen;
	}
	public int getTwenty() {
		return twenty;
	}
	public void setTwenty(int twenty) {
		this.twenty = twenty;
	}
	public int getTwentyone() {
		return twentyone;
	}
	public void setTwentyone(int twentyone) {
		this.twentyone = twentyone;
	}
	public int getTwentytwo() {
		return twentytwo;
	}
	public void setTwentytwo(int twentytwo) {
		this.twentytwo = twentytwo;
	}
	public int getC() {
		return c;
	}
	public void setC(int c) {
		this.c = c;
	}
	public int getVc() {
		return vc;
	}
	public void setVc(int vc) {
		this.vc = vc;
	}
	
	
	
	
	

}
